#include <stdio.h>

int foo(int a, int b) {
	int i = a;
	int j = b;
	return 5;
}

int main() {
	foo(3, 4);
}
